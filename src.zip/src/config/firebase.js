// // Initialize Firebase
// var config = {
//     apiKey: "AIzaSyAVjzLAX7YzDSJueE2VxUxqDZawSZlJTt8",
//     authDomain: "patrimoine-pontault-combault.firebaseapp.com",
//     databaseURL: "https://patrimoine-pontault-combault.firebaseio.com",
//     projectId: "patrimoine-pontault-combault",
//     storageBucket: "patrimoine-pontault-combault.appspot.com",
//     messagingSenderId: "1069741740602"
//   };
  
//   export default config;

  // Initialize Firebase
var config = {
    apiKey: "AIzaSyAVjzLAX7YzDSJueE2VxUxqDZawSZlJTt8",
    authDomain: "reatlime-maps.firebaseapp.com",
    databaseURL: "https://reatlime-maps.firebaseio.com",
    projectId: "reatlime-maps",
    storageBucket: "reatlime-maps.appspot.com",
    messagingSenderId: "1069741740602"
  };
  
  export default config;