import Vue from "vue";
import { rtdbPlugin as VueFire } from 'vuefire'

Vue.use(VueFire);